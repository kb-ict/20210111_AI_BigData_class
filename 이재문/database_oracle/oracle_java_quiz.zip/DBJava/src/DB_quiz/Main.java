package DB_quiz;

import java.sql.Connection;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Connection conn = null; // DB연결된 상태(세션)을 담은 객체

		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("INPUT DB USERNAME\t");
			String userId = sc.nextLine();
			conn = DBconn.getConnection(userId);
//			conn = Singleton_DBconn.getConnection();// singleton 객체 연습?
			if (conn == null)// DB 연결 없으면 종료~
			{
				System.out.println(">>No Database connection.\n>>Exit Program.");
				sc.close();
				return;
			}
			Client_DDL user_ddl = new Client_DDL(conn);
			user_ddl.checkTable();
			user_ddl.checkSeq();

			Client_DML user_dml = new Client_DML(conn);
			Console_box cb = new Console_box(user_dml, sc);
			cb.init();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)// 커넥션 해제
					conn.close();
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		System.out.println("Program End");
	}
}
