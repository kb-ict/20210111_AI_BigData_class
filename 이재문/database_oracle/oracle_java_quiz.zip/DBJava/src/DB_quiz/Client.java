package DB_quiz;

public class Client {
	private int cid;// (pk)식별번호 자동증가(1~9999)
	private String cname;// (nullable)이름
	private int cage;// (nn)나이 0~999
	private String cgender;// (nn)성별 m(male)|f(female)

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public int getCage() {
		return cage;
	}

	public void setCage(int cage) {
		this.cage = cage;
	}

	public String getCgender() {
		return cgender;
	}

	public void setCgender(String cgender) {
		this.cgender = cgender;
	}

	public Client(int cid, String cname, int cage, String cgender) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.cage = cage;
		this.cgender = cgender;
	}

	public Client() {
		//
	}

	@Override
	public String toString() {
		String str = new StringBuilder().append("Client\n").append("ID\t[" + cid + "]\n")
				.append("Name\t[" + cname + "]\n").append("Age\t[" + cage + "]\n").append("Gender\t[" + cgender + "]\n")
				.toString();
		return str;
	}

	public String print(boolean[] columns) {
		StringBuilder sb = new StringBuilder();
		sb.append("Client\n");
		if (columns[0])
			sb.append("ID\t[" + cid + "]\n");
		if (columns[1])
			sb.append("Name\t[" + cname + "]\n");
		if (columns[2])
			sb.append("Age\t[" + cage + "]\n");
		if (columns[3])
			sb.append("Gender\t[" + cgender + "]\n");
		return sb.toString();
	}
}
