package DB_quiz;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Client_DML {
	private Connection sub_conn = null; // DB연결된 상태(세션)을 담은 객체
	private CallableStatement cs = null;// 저장 프로시저 객체
	private Statement stmt = null;
	private ResultSet sub_rs = null; // 쿼리문을 날린것에 대한 반환값을 담을 객체
	private List<Client> arr_client = null;// Client 테이블 객체 배열
	private Client temp_client = null;// Client 테이블 객체
//	private PreparedStatement sub_pstm = null; // SQL 문을 나타내는 객체

	public Client_DML(Connection c) {
		this.sub_conn = c;
	}

	// return -1&0: error | 1: success
	public int insert(String name, int age, String gender) {
		// insert into ai.client(cname, cage, cgender)
		// values(c_name, c_age, c_gender);
		int resultRowCnt = -1;
		try {
			// 프로시저 호출
			cs = sub_conn.prepareCall("BEGIN C_INSERT(?,?,?); END;");
			// 입력 패러미터
			cs.setString(1, name);// 이름
			cs.setInt(2, age);// 나이
			cs.setString(3, gender);// 성별(m:male, f:female)
			// executeUpdate()
			resultRowCnt = cs.executeUpdate();

			if (resultRowCnt == 0)
				System.out.println("INSERT ERROR");
			else if (resultRowCnt == 1)
				System.out.println("INSERT SUCCESS");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (cs != null)
					cs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultRowCnt;
	}

	public static enum Del_condition {
		id, name, age, gender;
	}

	// return -1&0: error | else: delete row count
	public int delete(Del_condition opt, String val) {
		// delete ai.client
		// where condition = val;
		int resultRowCnt = -1;
		int condition_opt = -1;
		String val_str = "default";
		int val_int = -1;
		try {
			// 프로시저 호출
			cs = sub_conn.prepareCall("BEGIN C_DELETE(?,?,?); END;");
			// 입력 패러미터
			switch (opt) {
			case id:
				condition_opt = 0;
				val_int = Integer.parseInt(val);
				break;
			case name:
				condition_opt = 1;
				val_str = val;
				break;
			case age:
				condition_opt = 2;
				val_int = Integer.parseInt(val);
				break;
			case gender:
				condition_opt = 3;
				val_str = val;
				break;
			}
			// System.out.printf("BEGIN C_DELETE(%d,%s,%d); END;",
			// condition_opt, val_str, val_int);

			cs.setInt("opt", condition_opt);
			cs.setString("val_String", val_str);
			cs.setInt("val_int", val_int);

			// executeUpdate()
			resultRowCnt = cs.executeUpdate();

			if (resultRowCnt == 0)
				System.out.println("DELETE ERROR");
			else
				System.out.println("DELETE " + resultRowCnt + " ROW(s)");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (cs != null)
					cs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultRowCnt;
	}

	public int update(int cid, String cname_flag, String cname, String cage_flag, int cage, String cgender_flag,
			String cgender) {
		// delete와 같이 프로시저 내에서 칼럼에 조건을 걸 수 없기에 세 번 돌려야 할 듯 하다.
		// update ai.client set cname = c_name where cid=c_id;
		// update ai.client set cage = c_age where cid=c_id;
		// update ai.client set cgender = c_gender where cid=c_id;
		int resultRowCnt = -1;
		try {
			// 프로시저 호출
			cs = sub_conn.prepareCall("BEGIN C_MODIFY(?,?,?,?,?,?,?); END;");
			// 입력 패러미터
			cs.setInt("c_id", cid);// cid
			cs.setString("flag_name", cname_flag);// cname_flag
			cs.setString("c_name", cname);// cname
			cs.setString("flag_age", cage_flag);// cage_flag
			cs.setInt("c_age", cage);// cage
			cs.setString("flag_gender", cgender_flag);// cgender_flag
			cs.setString("c_gender", cgender);// cgender
			// executeUpdate()
			resultRowCnt = cs.executeUpdate();

			if (resultRowCnt == 0)
				System.out.println("UPDATE ERROR");
			else if (resultRowCnt == 1)
				System.out.println("UPDATE SUCCESS");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (cs != null)
					cs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultRowCnt;
	}

	public void select(boolean defCol, boolean defWhere, boolean[] cols, boolean[] conditions, Object[] val) {
		// select * from ai.client
		// where condition_name[i] = condition_val[i];

		if (defCol && defWhere) {// 프로시저 사용 X
			try {
				arr_client = new ArrayList<Client>();
				String sql_query = "select * from client";
				stmt = sub_conn.createStatement();
				sub_rs = (ResultSet) stmt.executeQuery(sql_query);

				while (sub_rs.next()) {
					temp_client = new Client(sub_rs.getInt("cid"), sub_rs.getString("cname"), sub_rs.getInt("cage"),
							sub_rs.getString("cgender"));
					arr_client.add(temp_client);
				}
				System.out.println("=─=─=─=─=─=─=─=─=─=─=─=─=─=─=");
				for (Client c : arr_client)
					System.out.println(c.toString());
				System.out.println("=─=─=─=─=─=─=─=─=─=─=─=─=─=─=");
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (sub_rs != null)
						sub_rs.close();
					if (stmt != null)
						stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		} else {// 프로시저 사용 O
			try {
				arr_client = new ArrayList<Client>();
				// 쿼리 짜기
				/*
				 * select * from client where cid = param_cid and cname = param_cname and cage =
				 * param_cage and cgender = param_cgender;
				 */
				String query;
				StringBuilder sb = new StringBuilder();
				sb.append("select ").append(checkCol(cols)).append(" from client");
				if (!defWhere) {
					sb.append(" where ");

					if (conditions[0])
						sb.append("cid = " + val[0]);
					if (conditions[1]) {
						if (conditions[0])
							sb.append(" and ");
						sb.append("cname = '" + val[1] + "'");
					}
					if (conditions[2]) {
						if (conditions[0] || conditions[1])
							sb.append(" and ");
						sb.append("cage = " + val[2]);
					}
					if (conditions[3]) {
						if (conditions[0] || conditions[1] || conditions[2])
							sb.append(" and ");
						sb.append("cgender = '" + val[3] + "'");
					}
				}

				query = sb.toString();

				stmt = sub_conn.createStatement();
				System.out.println(">> " + query);
				sub_rs = (ResultSet) stmt.executeQuery(query);

				while (sub_rs.next()) {
					temp_client = new Client();
					if (cols[0])
						temp_client.setCid(sub_rs.getInt("cid"));
					if (cols[1])
						temp_client.setCname(sub_rs.getString("cname"));
					if (cols[2])
						temp_client.setCage(sub_rs.getInt("cage"));
					if (cols[3])
						temp_client.setCgender(sub_rs.getString("cgender"));

					arr_client.add(temp_client);
				}
				System.out.println("=─=─=─=─=─=─=─=─=─=─=─=─=─=─=");
				for (Client c : arr_client)
					System.out.println(c.print(cols));
				System.out.println("=─=─=─=─=─=─=─=─=─=─=─=─=─=─=");
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (sub_rs != null)
						sub_rs.close();
					if (stmt != null)
						stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
	}

	private String checkCol(boolean[] ba) {
		int col_binary = 0;
		col_binary += (ba[0]) ? 1 : 0;
		col_binary += (ba[1]) ? 2 : 0;
		col_binary += (ba[2]) ? 4 : 0;
		col_binary += (ba[3]) ? 8 : 0;

		String str;
		StringBuilder sb = new StringBuilder();
		switch (col_binary) {
		case 0:
			// none
			sb.append("");
			break;
		case 1:
			// cid
			sb.append("cid");
			break;
		case 2:
			// cname
			sb.append("cname");
			break;
		case 3:
			// cid, cname
			sb.append("cid, cname");
			break;
		case 4:
			// cage
			sb.append("cage");
			break;
		case 5:
			// cid, cage
			sb.append("cid, cage");
			break;
		case 6:
			// cname, cage
			sb.append("cname, cage");
			break;
		case 7:
			// cid, cname, cage
			sb.append("cid, cname, cage");
			break;
		case 8:
			// cgender
			sb.append("cgender");
			break;
		case 9:
			// cid, cgender
			sb.append("cid, cgender");
			break;
		case 10:
			// cname, cgender
			sb.append("cname, cgender");
			break;
		case 11:
			// cid, cname, cgender
			sb.append("cid, cname, cgender");
			break;
		case 12:
			// cage, cgender
			sb.append("cage, cgender");
			break;
		case 13:
			// cid, cage, cgender
			sb.append("cid, cage, cgender");
			break;
		case 14:
			// cname, cage, cgender
			sb.append("cname, cage, cgender");
			break;
		case 15:
			// cid, cname, cage, cgender
			sb.append("*");
			break;
		}
		str = sb.toString();
		return str;
	}
}
