package DB_quiz;

import java.util.Scanner;

import DB_quiz.Client_DML.Del_condition;

public class Console_box {
	Scanner scan;
	Client_DML cd;
	Del_condition del_con;

	public Console_box(Client_DML temp, Scanner sc) {
		this.cd = temp;
		this.scan = sc;
	}

	private final String INIT = new StringBuilder().append("┌───────────────────────────┐\n")
			.append(" >> Client Table\n").append(" 1. select\t").append(" 2. insert\n").append(" 3. update\t")
			.append(" 4. delete\n").append(" Q|q. EXIT Program.\n").append("└───────────────────────────┘").toString();
	private final String SELECT_1 = new StringBuilder().append(" >> What column(s) do you want to see?\n")
			.append(" 1. CID\t\t").append(" 2. CNAME\n").append(" 3. CAGE\t").append(" 4. CGENDER\n")
			.append(" Q|q. ALL(*) or Stop choosing columns\n").toString();
	private final String SELECT_2 = new StringBuilder().append(" >> Where?\n").append(" 1. CID(Key)\t")
			.append(" 2. CNAME\n").append(" 3. CAGE\t").append(" 4. CGENDER\n")
			.append(" Q|q. None or Stop choosing columns\\n").toString();
	private final String SELECT_2_1 = new StringBuilder().append(" >> CID(Key, int) Value?\t").toString();
	private final String SELECT_2_2 = new StringBuilder().append(" >> CNAME(String) Value?\t").toString();
	private final String SELECT_2_3 = new StringBuilder().append(" >> CAGE(int) Value?\t").toString();
	private final String SELECT_2_4 = new StringBuilder().append(" >> CGENDER(M/m: Male, F/f: Female) Value?\t")
			.toString();
	private final String INSERT_1 = new StringBuilder().append(" >> input\n").append(" 1. 이름:\t").toString();
	private final String INSERT_2 = new StringBuilder().append(" >> input\n").append(" 2. 나이:\t").toString();
	private final String INSERT_3 = new StringBuilder().append(" >> input\n")
			.append(" 3. 성별(M/m: Male, F/f: Female):\t").toString();
	private final String UPDATE_1 = new StringBuilder().append(">> CID(Key) Value?\t").toString();
	private final String UPDATE_2 = new StringBuilder().append(">> update name?(y/n)\t").toString();
	private final String UPDATE_2_1 = new StringBuilder().append(">> name?\t").toString();
	private final String UPDATE_3 = new StringBuilder().append(">> update age?(y/n)\t").toString();
	private final String UPDATE_3_1 = new StringBuilder().append(">> age?\t").toString();
	private final String UPDATE_4 = new StringBuilder().append(">> update gender?(y/n)\t").toString();
	private final String UPDATE_4_1 = new StringBuilder().append(">> gender?\t").toString();
	private final String DELETE_1 = new StringBuilder().append(" >> Where?\n").append(" 1. id\t").append(" 2. name\n")
			.append(" 3. age\t").append(" 4. gender\n").toString();
	private final String DELETE_2 = new StringBuilder().append(" >> Value?\n").toString();

	public void init() {
//		scan = new Scanner(System.in);
		int opt = -1;
		String temp = null;
		do {
			System.out.println(INIT);
			temp = scan.nextLine();
			if (Helper.isNumeric(temp) && Helper.isXtoY(temp, 0, 5)) {
				opt = Integer.parseInt(temp);
				switch (opt) {
				case 1:
					select();
					break;
				case 2:
					insert();
					break;
				case 3:
					update();
					break;
				case 4:
					delete();
					break;
				}
				continue;
			} else if (temp.toLowerCase().equals("q"))
				break;
		} while (true);
		scan.close();
	}

	private void select() {
		// columns
		boolean col_def = false;
		// cols[0]: cid
		// cols[1]: cname
		// cols[2]: cage
		// cols[3]: cgender
		boolean[] cols = { false, false, false, false };

		// conditions
		boolean cnd_def = false;
		// conditions[0]: where cid = ?
		// conditions[1]: where cname = ?
		// conditions[2]: where cage = ?
		// conditions[3]: where cgender = ?
		boolean[] conditions = { false, false, false, false };
		// values
		Object[] param = { -1, "default", -1, "" };
		// variable
		String temp = "";
		// choose column(s)
		do {
			System.out.println(SELECT_1);
			temp = scan.nextLine();
			if (temp.toLowerCase().equals("q")) {
				if (cols[0] || cols[1] || cols[2] || cols[3]) {
					break;
				} else {
					System.out.println(" >> PICK * AUTOMATICALLY.\n");
					col_def = true;
					cols[0] = true;
					cols[1] = true;
					cols[2] = true;
					cols[3] = true;
					break;
				}
			} else if (Helper.isNumeric(temp) && Helper.isXtoY(temp, 0, 5)) {
				switch (Integer.parseInt(temp)) {
				case 1:
					cols[0] = true;
					break;
				case 2:
					cols[1] = true;
					break;
				case 3:
					cols[2] = true;
					break;
				case 4:
					cols[3] = true;
					break;
				}
				continue;
			} else {
				System.out.println(" >> Invalid input data.");
				continue;
			}
		} while (true);

		// condition?
		do {
			System.out.println(SELECT_2);
			temp = scan.nextLine();
			if (temp.toLowerCase().equals("q")) {
				if (conditions[0] || conditions[1] || conditions[2] || conditions[3]) {
					break;
				} else {
					System.out.println(" >> No WHERE clause.\n");
					cnd_def = true;
					break;
				}
			} else if (Helper.isNumeric(temp) && Helper.isXtoY(temp, 0, 5)) {
				switch (Integer.parseInt(temp)) {
				case 1:
					conditions[0] = true;
					break;
				case 2:
					conditions[1] = true;
					break;
				case 3:
					conditions[2] = true;
					break;
				case 4:
					conditions[3] = true;
					break;
				}
				continue;
			} else {
				System.out.println(" >> Invalid input data.");
				continue;
			}
		} while (true);
		// where clause(s) details
		if (conditions[0]) {
			do {
				System.out.println(SELECT_2_1);
				temp = scan.nextLine();
				if (Helper.isNumeric(temp))
					break;
			} while (true);
			param[0] = Integer.parseInt(temp);
		}
		if (conditions[1]) {
			do {
				System.out.println(SELECT_2_2);
				temp = scan.nextLine();
				if (true)
					break;
			} while (true);
			param[1] = temp;
		}
		if (conditions[2]) {
			do {
				System.out.println(SELECT_2_3);
				temp = scan.nextLine();
				if (Helper.isNumeric(temp))
					break;
			} while (true);
			param[2] = Integer.parseInt(temp);
		}
		if (conditions[3]) {
			do {
				System.out.println(SELECT_2_4);
				temp = scan.nextLine();
				if (Helper.isGender(temp))
					break;
			} while (true);
			param[3] = temp;
		}

		this.cd.select(col_def, cnd_def, cols, conditions, param);
	}

	private void insert() {
		String nm, temp_ag, gd;
		int ag;
		System.out.println(INSERT_1);
		nm = scan.nextLine();
		do {
			System.out.println(INSERT_2);
			temp_ag = scan.nextLine();
		} while (!Helper.isNumeric(temp_ag));
		ag = Integer.parseInt(temp_ag);
		do {
			System.out.println(INSERT_3);
			gd = scan.nextLine().toLowerCase();
		} while (!Helper.isGender(gd));
		this.cd.insert(nm, ag, gd);
	}

	private void update() {
		String temp_cid = null;
		String cnm = "temp";
		String temp_cag = null;
		String cgd = "f";// m|f
		String yesOrNo_name = "n";
		String yesOrNo_age = "n";
		String yesOrNo_gender = "n";
		int key_cid = -1;
		int cag = -1;
		// cid(key)
		do {
			System.out.println(UPDATE_1);
			temp_cid = scan.nextLine();
		} while (!Helper.isNumeric(temp_cid));
		key_cid = Integer.parseInt(temp_cid);
		// cname
		do {
			System.out.println(UPDATE_2);
			yesOrNo_name = scan.nextLine().toLowerCase();
		} while (!Helper.isYesOrNo(yesOrNo_name));
		if (yesOrNo_name.equals("y")) {
			System.out.println(UPDATE_2_1);
			cnm = scan.nextLine();
		}
		// cage
		do {
			System.out.println(UPDATE_3);
			yesOrNo_age = scan.nextLine().toLowerCase();
		} while (!Helper.isYesOrNo(yesOrNo_age));
		if (yesOrNo_age.equals("y")) {
			do {
				System.out.println(UPDATE_3_1);
				temp_cag = scan.nextLine();
			} while (!Helper.isNumeric(temp_cag));
			cag = Integer.parseInt(temp_cag);
		}
		// cgender
		do {
			System.out.println(UPDATE_4);
			yesOrNo_gender = scan.nextLine().toLowerCase();
		} while (!Helper.isYesOrNo(yesOrNo_gender));
		if (yesOrNo_gender.equals("y")) {
			do {
				System.out.println(UPDATE_4_1);
				cgd = scan.nextLine().toLowerCase();
			} while (!Helper.isGender(cgd));
		}

		this.cd.update(key_cid, yesOrNo_name, cnm, yesOrNo_age, cag, yesOrNo_gender, cgd);
	}

	private void delete() {
		String temp_del_opt;
		int del_opt;
		do {
			System.out.println(DELETE_1);
			temp_del_opt = scan.nextLine();
		} while (!Helper.isNumeric(temp_del_opt) || !Helper.isXtoY(temp_del_opt, 0, 5));
		del_opt = Integer.parseInt(temp_del_opt);

		switch (del_opt) {
		case 1:
			del_con = Del_condition.id;
			break;
		case 2:
			del_con = Del_condition.name;
			break;
		case 3:
			del_con = Del_condition.age;
			break;
		case 4:
			del_con = Del_condition.gender;
			break;
		}
		System.out.println(DELETE_2);
		String dep_val = scan.nextLine();
		this.cd.delete(del_con, dep_val);
	}
}
