package DB_quiz;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Client_DDL {
	private Connection sub_conn = null; // DB연결된 상태(세션)을 담은 객체
	private Statement stmt = null;

	public Client_DDL(Connection c) {
		this.sub_conn = c;
	}

	public boolean checkTable() {
		// select table_name from tabs where table_name in 'CLIENT'
		int resultRowCnt = -1;
		try {
			System.out.println("Check Client table...");
			stmt = sub_conn.createStatement();
			String sql_query = "select table_name from tabs where table_name in 'CLIENT'";
			resultRowCnt = stmt.executeUpdate(sql_query);

			if (resultRowCnt == 0) {
				System.out.println("No Table. So Made it.");
				String sql_query2 = "CREATE TABLE CLIENT(CID NUMBER(4) PRIMARY KEY, CNAME VARCHAR2(20), CAGE NUMBER(3) NOT NULL, CGENDER CHAR(1) NOT NULL)";
				stmt.executeUpdate(sql_query2);
			} else if (resultRowCnt == 1)
				System.out.println("Already Exist. Ready to go!");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return (resultRowCnt != 0) ? true : false;
	}

	public boolean checkSeq() {
		// select sequence_name from user_sequences where sequence_name in
		// 'C_INSERT_SEQ'
		int resultRowCnt = -1;
		try {
			System.out.println("Check sequence for Client table...");
			stmt = sub_conn.createStatement();
			String sql_query = "select sequence_name from user_sequences where sequence_name in 'C_INSERT_SEQ'";
			resultRowCnt = stmt.executeUpdate(sql_query);

			if (resultRowCnt == 0) {
				System.out.println("No Sequence. So Made it.");
				String sql_query2 = "CREATE SEQUENCE c_insert_seq START WITH 1 INCREMENT BY 1 MAXVALUE 9999 CYCLE NOCACHE";
				stmt.executeUpdate(sql_query2);
			} else if (resultRowCnt == 1)
				System.out.println("Already Exist. Ready to go!");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return (resultRowCnt != 0) ? true : false;
	}
}
