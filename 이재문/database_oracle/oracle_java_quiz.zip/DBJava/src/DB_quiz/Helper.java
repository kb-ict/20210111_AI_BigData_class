package DB_quiz;

import java.util.regex.Pattern;

public class Helper {
	public static boolean isNumeric(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

	// 정규식(Regular Expressions)으로 m/f 구분
	public static boolean isGender(String str) {
		str = str.toLowerCase();
		Pattern genderPattern = Pattern.compile("(^[m,f]$)");
		if (str == null) {
			return false;
		}
		return genderPattern.matcher(str).matches();
	}

	public static boolean isXtoY(String num, int x, int y) {
		if (num == null)
			return false;
		if (x == y)
			return false;
		if (x < y) {
			if (Integer.parseInt(num) > x && Integer.parseInt(num) < y)
				return true;
			else
				return false;
		} else {
			if (Integer.parseInt(num) > y && Integer.parseInt(num) < x)
				return true;
			else
				return false;
		}
	}

	public static boolean isYesOrNo(String str) {
		str = str.toLowerCase();
		Pattern genderPattern = Pattern.compile("(^[y,n]$)");
		if (str == null) {
			return false;
		}
		return genderPattern.matcher(str).matches();
	}
}
